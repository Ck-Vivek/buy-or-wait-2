import argparse
import os
import sys
import logging

# Ensure project root is in python path
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from src.main import main as run_pipeline

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
)
logger = logging.getLogger(__name__)

def parse_args():
    parser = argparse.ArgumentParser(
        description="Buy or Wait: AI Financial Decision Agent"
    )
    parser.add_argument(
        "--dataset",
        type=str,
        default=r"C:\Users\ASUS\Documents\hackerrank-orchestrate-september26-main\dataset",
        help="Path to the dataset directory containing the input CSV files and images."
    )
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Path for the output CSV file. Defaults to output.csv inside the dataset directory."
    )
    return parser.parse_args()

def cli():
    args = parse_args()
    
    dataset_path = os.path.abspath(args.dataset)
    if not os.path.exists(dataset_path):
        logger.error(f"Dataset directory not found: {dataset_path}")
        sys.exit(1)
        
    output_path = args.output
    if not output_path:
        output_path = os.path.join(dataset_path, "output.csv")
    output_path = os.path.abspath(output_path)
    
    output_dir = os.path.dirname(output_path)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)
        
    logger.info("==========================================")
    logger.info(" Starting Buy or Wait Financial Pipeline ")
    logger.info(f" Dataset Path: {dataset_path}")
    logger.info(f" Output Path:  {output_path}")
    logger.info("==========================================")
    
    try:
        run_pipeline(dataset_path, output_path)
        logger.info("Execution finished successfully.")
    except Exception as e:
        logger.exception(f"Fatal error during execution: {e}")
        sys.exit(1)

if __name__ == "__main__":
    cli()
