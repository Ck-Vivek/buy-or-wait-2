# AI Usage Report

**Project:** Buy-or-Wait AI Financial Decision Agent  
**Run audited:** Final local 250-request pipeline, 2026-09-13  
**Environment:** Offline/cache-backed execution; no Gemini API key was configured.

## Final Run Facts

The final pipeline processed 250 requests successfully. During the audited run:

- No external Gemini API calls were made.
- No input or output tokens were consumed by an external model.
- No API cost was incurred by the audited run.
- The VLM path used 16 validated cache records:
  - 15 local RapidOCR records.
  - 1 verified `image_14` record with method
    `gemini_verified_visual_audit`.
- The message parser used the existing 215-record `llm_cache.json` cache.
- Decision explanations were generated from the deterministic fact-locked
  template or existing explanation cache; no external explanation-model calls
  were made.

The cache sizes are inventory facts, not historical API call counts. The local
cache files do not contain provider billing metadata, input-token counts,
output-token counts, or historical timestamps sufficient to reconstruct prior
API usage.

## What Is Known and Unknown

| Metric | Final audited run |
|---|---:|
| Requests processed | 250 |
| External Gemini calls | 0 |
| External input tokens | Not applicable: no external calls |
| External output tokens | Not applicable: no external calls |
| External API cost | $0.00 |
| Validated image records used | 16 |
| Message cache records available | 215 |

Historical API usage, if any occurred before the final offline run, cannot be
verified from the repository. No historical token or billing values are claimed
here.

## AI Boundaries

The implementation keeps financial arithmetic and decision rules deterministic:

- Image perception is handled by `VLMAdapter`, local RapidOCR, and validated
  cache records.
- Message perception is handled by `LLMAdapter`, its conservative local parser,
  and validated cache records.
- Financial normalization, lifecycle resolution, recurrence inference,
  simulation, solver ranking, and validation run in Python with `Decimal` where
  monetary arithmetic is required.
- Explanations are generated from locked decision facts using the deterministic
  template when no external model is available.

## Reproducibility Note

A future run with `GEMINI_API_KEY` configured may make external Gemini calls for
cache misses. That usage is not represented as actual usage in this report.
