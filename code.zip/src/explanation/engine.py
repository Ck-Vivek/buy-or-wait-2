"""Fact-locked explanation engine per PRD §21.
Generates explanations ONLY from locked decision facts.
The LLM must not introduce new financial information or modify any numeric decision."""

import os
import json
import requests
import hashlib

CACHE_FILE = os.path.join(os.path.dirname(__file__), 'explanation_cache.json')

def load_cache():
    if os.path.exists(CACHE_FILE):
        with open(CACHE_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_cache(cache_dict):
    with open(CACHE_FILE, 'w') as f:
        json.dump(cache_dict, f, indent=2)


def generate_explanation(decision_facts: dict, api_key: str = None) -> str:
    """
    Generate a fact-locked explanation from the verified decision object.
    The LLM receives ONLY verified facts and must not introduce new financial information.
    Falls back to a deterministic template if no API key is available.
    """
    cache = load_cache()
    cache_key = hashlib.md5(json.dumps(decision_facts, sort_keys=True, default=str).encode()).hexdigest()
    
    if cache_key in cache:
        return cache[cache_key]
    
    # Build the deterministic template explanation (always works, no API needed)
    explanation = _build_template_explanation(decision_facts)
    
    api_key = api_key or os.environ.get("GEMINI_API_KEY")
    if api_key:
        try:
            llm_explanation = _call_llm_explanation(decision_facts, api_key)
            if llm_explanation:
                explanation = llm_explanation
        except Exception:
            pass  # Fall back to template
    
    cache[cache_key] = explanation
    save_cache(cache)
    return explanation


def _build_template_explanation(facts: dict) -> str:
    """Build a deterministic explanation from decision facts."""
    status = facts.get('affordability_status', '')
    method = facts.get('recommended_payment_method', '')
    amount_safe = facts.get('amount_safe_to_pay', '0')
    requested = facts.get('requested_amount', '0')
    currency = facts.get('home_currency', '')
    earliest = facts.get('earliest_date_for_full_payment', '')
    changes = facts.get('spending_changes_needed', 'none')
    min_balance = facts.get('minimum_balance', '0')
    
    if status == 'affordable_now':
        return (f"Pay {currency} {requested} today. "
                f"After this payment, the balance stays above the {currency} {min_balance} minimum "
                f"throughout the next 90 days.")
    
    elif status == 'affordable_with_plan':
        if method == 'partial_payment':
            return (f"Pay {currency} {amount_safe} today and the remaining "
                    f"{currency} {facts.get('remaining_amount', '')} on {earliest}. "
                    f"This keeps the balance above {currency} {min_balance} throughout.")
        elif method == 'installments':
            opt_id = facts.get('payment_option_id', '')
            return (f"Use installment plan {opt_id}. "
                    f"The balance stays above {currency} {min_balance} throughout the payment schedule.")
        elif method == 'full_payment' and changes != 'none':
            return (f"Pay {currency} {requested} today after adjusting spending: {changes}. "
                    f"These changes keep the balance above {currency} {min_balance}.")
        else:
            return (f"Affordable with a payment plan using {method}. "
                    f"The balance stays above the minimum throughout.")
    
    elif status == 'affordable_later':
        return (f"Wait until {earliest} to pay {currency} {requested} in full. "
                f"The balance is projected to support the full amount safely by then.")
    
    elif status == 'not_affordable':
        return (f"The full {currency} {requested} cannot be completed safely within 90 days. "
                f"The maximum safe amount today is {currency} {amount_safe}.")
    
    return f"Decision: {status}, method: {method}."


def _call_llm_explanation(facts: dict, api_key: str) -> str:
    """Call the LLM to generate a natural-language explanation from locked facts."""
    url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-pro:generateContent"
    
    # The prompt explicitly states that facts are locked and cannot be changed
    prompt = f"""You are a financial advisor writing a brief explanation of a financial decision.

IMPORTANT: The following facts are VERIFIED and LOCKED. You must NOT change any numbers, dates, 
or decisions. You must NOT introduce any new financial information. Simply explain the decision 
in clear, concise language.

LOCKED DECISION FACTS:
- Affordability Status: {facts.get('affordability_status', '')}
- Recommended Method: {facts.get('recommended_payment_method', '')}
- Amount Safe to Pay Today: {facts.get('home_currency', '')} {facts.get('amount_safe_to_pay', '')}
- Requested Amount: {facts.get('home_currency', '')} {facts.get('requested_amount', '')}
- Earliest Full Payment Date: {facts.get('earliest_date_for_full_payment', 'not within forecast')}
- Spending Changes Needed: {facts.get('spending_changes_needed', 'none')}
- Minimum Balance Requirement: {facts.get('home_currency', '')} {facts.get('minimum_balance', '')}

Write a 1-2 sentence explanation. Use only the facts above. Do not add disclaimers or caveats."""

    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.0, "maxOutputTokens": 200}
    }
    
    resp = requests.post(f"{url}?key={api_key}", json=payload)
    resp.raise_for_status()
    data = resp.json()
    return data['candidates'][0]['content']['parts'][0]['text'].strip()
