"""Safety and Output validators per PRD §19-20."""

from decimal import Decimal, InvalidOperation
from datetime import date, datetime, timedelta
from typing import List, Dict, Optional
import re

from src.finance.models import PaymentPlan
from src.finance.simulator import Simulator


def verify_safety(plan: Optional[PaymentPlan], spending_changes: List[Dict], 
                  simulator: Simulator, requested_amount: Decimal,
                  desired_completion_date: Optional[date]) -> Dict:
    """
    Independent safety validator per PRD §19.
    Re-checks the complete financial plan against the PS:
    - Balance never falls below minimum_balance_to_keep
    - All payments are financially coverable
    - Full request is completed by the required deadline
    - Spending changes obey their constraints
    Returns dict with 'safe' bool and 'issues' list.
    """
    issues = []
    
    if plan is None:
        return {'safe': True, 'issues': []}

    for payment in plan.payments:
        if payment.amount <= 0:
            issues.append(f"Payment on {payment.date} is not positive: {payment.amount}")
        if payment.date < simulator.request_date or payment.date > simulator.end_date:
            issues.append(f"Payment date {payment.date} is outside the 90-day horizon")
        if desired_completion_date and payment.date > desired_completion_date:
            issues.append(f"Payment date {payment.date} is after desired completion {desired_completion_date}")
    
    # Check 1: Balance never falls below minimum throughout 90 days
    balances = simulator.generate_daily_balances(spending_changes, plan)
    min_balance_observed = min(balances.values())
    if min_balance_observed < simulator.minimum_balance:
        issues.append(f"Balance drops to {min_balance_observed} below minimum {simulator.minimum_balance}")
    
    # Check 2: All payments are coverable (balance on payment date >= payment amount + min_balance)
    if plan.payments:
        for p in plan.payments:
            if p.date in balances:
                if balances[p.date] < simulator.minimum_balance:
                    issues.append(f"Balance on payment date {p.date} is {balances[p.date]}, below minimum")
    
    # Check 3: Full request completed by desired_completion_date
    if plan.payments and desired_completion_date:
        total_paid = sum(p.amount for p in plan.payments)
        last_payment = max(p.date for p in plan.payments)
        if total_paid < requested_amount:
            issues.append(f"Plan total {total_paid} < requested {requested_amount}")
        if last_payment > desired_completion_date:
            issues.append(f"Plan completes on {last_payment} after desired completion {desired_completion_date}")
    
    # Check 4: Max 3 spending changes
    if len(spending_changes) > 3:
        issues.append(f"Too many spending changes: {len(spending_changes)}")
    
    # Check 5: No stop+reduce on same event
    change_events = {}
    for c in spending_changes:
        eid = c['event_id']
        if eid in change_events:
            if change_events[eid] != c['action']:
                issues.append(f"Both stop and reduce on event {eid}")
        change_events[eid] = c['action']
    
    return {'safe': len(issues) == 0, 'issues': issues}


VALID_STATUSES = {'affordable_now', 'affordable_with_plan', 'affordable_later', 'not_affordable'}
VALID_METHODS = {'full_payment', 'partial_payment', 'installments', 'wait', 'not_recommended'}


def verify_output_format(row: Dict) -> Dict:
    """
    Output format validator per PRD §20.
    Validates all enums, required fields, amount bounds, payment_plan syntax, etc.
    Returns dict with 'valid' bool and 'issues' list.
    """
    issues = []
    
    # Check required fields exist
    required_fields = ['request_id', 'amount_safe_to_pay', 'affordability_status', 
                       'recommended_payment_method', 'payment_plan', 
                       'earliest_date_for_full_payment', 'spending_changes_needed',
                       'decision_explanation']
    for f in required_fields:
        if f not in row or row[f] is None:
            issues.append(f"Missing required field: {f}")
            
    if issues:
        return {'valid': False, 'issues': issues}
    
    # Validate affordability_status enum
    if row['affordability_status'] not in VALID_STATUSES:
        issues.append(f"Invalid affordability_status: {row['affordability_status']}")
    
    # Validate recommended_payment_method enum
    if row['recommended_payment_method'] not in VALID_METHODS:
        issues.append(f"Invalid recommended_payment_method: {row['recommended_payment_method']}")
    
    # Validate amount_safe_to_pay is a valid number >= 0
    try:
        safe_amt = Decimal(row['amount_safe_to_pay'])
        if safe_amt < 0:
            issues.append(f"amount_safe_to_pay is negative: {safe_amt}")
    except (InvalidOperation, ValueError):
        issues.append(f"amount_safe_to_pay is not a valid number: {row['amount_safe_to_pay']}")
    
    # Validate payment_plan format
    plan_str = row['payment_plan']
    if plan_str != 'none':
        parts = plan_str.split('|')
        prev_date = None
        for part in parts:
            if ':' not in part:
                issues.append(f"Invalid payment_plan entry (no colon): {part}")
                continue
            date_str, amt_str = part.split(':', 1)
            # Validate date format
            try:
                d = datetime.strptime(date_str, '%Y-%m-%d').date()
                if prev_date and d < prev_date:
                    issues.append(f"Payment plan not chronological: {date_str} after {prev_date}")
                prev_date = d
            except ValueError:
                issues.append(f"Invalid date in payment_plan: {date_str}")
            # Validate amount
            try:
                Decimal(amt_str)
            except (InvalidOperation, ValueError):
                issues.append(f"Invalid amount in payment_plan: {amt_str}")
    
    # Validate spending_changes_needed format
    changes_str = row['spending_changes_needed']
    if changes_str != 'none':
        change_parts = changes_str.split('|')
        if len(change_parts) > 3:
            issues.append(f"More than 3 spending changes")
        for cp in change_parts:
            if cp.startswith('stop:'):
                # stop:event_id format
                if len(cp.split(':')) != 2:
                    issues.append(f"Invalid stop format: {cp}")
            elif cp.startswith('reduce_to:'):
                # reduce_to:event_id:new_amount format
                parts = cp.split(':')
                if len(parts) != 3:
                    issues.append(f"Invalid reduce_to format: {cp}")
                else:
                    try:
                        Decimal(parts[2])
                    except (InvalidOperation, ValueError):
                        issues.append(f"Invalid amount in reduce_to: {parts[2]}")
            else:
                issues.append(f"Unknown spending change type: {cp}")
    
    # Validate earliest_date_for_full_payment
    edf = row['earliest_date_for_full_payment']
    if edf:
        try:
            datetime.strptime(edf, '%Y-%m-%d')
        except ValueError:
            issues.append(f"Invalid earliest_date format: {edf}")
    
    # For affordable_now, earliest must equal request_date 
    # (we don't have request_date here, so we just check it's not blank)
    if row['affordability_status'] == 'affordable_now' and not edf:
        issues.append("affordable_now requires earliest_date_for_full_payment")
    
    # Validate decision_explanation is not empty
    if not row['decision_explanation'].strip():
        issues.append("decision_explanation is empty")
        
    # Consistency checks
    status = row['affordability_status']
    method = row['recommended_payment_method']
    
    if status == 'affordable_now' and method != 'full_payment':
        issues.append(f"affordable_now requires full_payment, got {method}")
    if status == 'affordable_later' and method != 'wait':
        issues.append(f"affordable_later requires wait, got {method}")
    if status == 'not_affordable' and method != 'not_recommended':
        issues.append(f"not_affordable requires not_recommended, got {method}")
    if status == 'not_affordable' and plan_str != 'none':
        issues.append(f"not_affordable should have payment_plan=none")
    
    return {'valid': len(issues) == 0, 'issues': issues}
