import csv
import os
import sys
from decimal import Decimal
from datetime import datetime
import logging

from src.ingestion.loaders import DatasetLoader
from src.ingestion.joins import DeterministicJoiner
from src.adapters.vlm import VLMAdapter
from src.adapters.llm import LLMAdapter
from src.finance.currency import CurrencyNormalizer
from src.finance.lifecycle import LifecycleResolver
from src.finance.simulator import Simulator
from src.finance.solver import Solver
from src.explanation.engine import generate_explanation
from src.validation.validators import verify_safety, verify_output_format

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def format_decimal(d: Decimal) -> str:
    """Format decimal without trailing zeros if it's an integer."""
    if d == d.to_integral_value():
        return str(d.to_integral_value())
    return str(d.normalize())

def process_request(req_id: str, joiner: DeterministicJoiner, vlm: VLMAdapter, llm: LLMAdapter, normalizer: CurrencyNormalizer, image_amounts: dict, structured_messages: list, image_sources: dict = None) -> dict:
    data = joiner.get_data_for_request(req_id)
    req = data.request
    prof = data.profile
    
    req_date = datetime.strptime(req['request_date'], '%Y-%m-%d').date()
    desired_date_str = req['desired_completion_date']
    desired_date = datetime.strptime(desired_date_str, '%Y-%m-%d').date() if desired_date_str else None
    requested_amount = Decimal(req['requested_amount'])
    allows_partial = req['allows_partial_payment'].lower() == 'true'
    
    home_currency = prof['home_currency']
    resolver = LifecycleResolver(normalizer, home_currency)
    
    # Filter messages for user
    user_msgs = [m for m in structured_messages if m['user_id'] == prof['user_id']]
    
    resolved_events = resolver.resolve(data.events, user_msgs, image_amounts, image_sources or {})
    
    curr_bal = Decimal(prof['current_available_balance'])
    min_bal = Decimal(prof['minimum_balance_to_keep'])
    
    sim = Simulator(curr_bal, min_bal, resolved_events, req_date)
    recurring_event_ids = sim.recurring_event_ids()
    
    # Build flexible events list
    flex_stop = [c.strip() for c in prof.get('expense_categories_user_is_willing_to_stop', '').split(';') if c.strip()]
    flex_reduce = [c.strip() for c in prof.get('expense_categories_user_is_willing_to_reduce', '').split(';') if c.strip()]
    
    flexible_events = []
    for e in resolved_events:
        if e.category in flex_stop or e.category in flex_reduce:
            # The PS permits changes only to flexible *recurring* expenses.
            if (e.event_id in recurring_event_ids
                    and e.direction == 'debit'
                    and e.flexibility in ('reducible', 'stoppable', 'reducible_or_stoppable')):
                flexible_events.append(e)
                
    prefs = [p.strip() for p in prof['payment_methods_user_will_consider'].split(';') if p.strip()]
    
    max_installment_months = prof.get('max_installment_months', '').strip()
    max_installments = int(max_installment_months) if max_installment_months else None
    solver = Solver(sim, requested_amount, desired_date, allows_partial, prefs, data.payment_options, flexible_events, max_installments)
    
    status, best_plan, best_combo = solver.solve()
    
    amt_safe = solver.get_amount_safe_to_pay()
    earliest_full = solver.get_earliest_full_date()
    
    # Format the payment plan
    plan_str = 'none'
    if best_plan and best_plan.payments:
        p_strs = [f"{p.date.strftime('%Y-%m-%d')}:{format_decimal(p.amount)}" for p in best_plan.payments]
        plan_str = '|'.join(p_strs)
        
    changes_str = 'none'
    if best_combo:
        c_strs = []
        for c in best_combo:
            if c['action'] == 'stop':
                c_strs.append(f"stop:{c['event_id']}")
            else:
                c_strs.append(f"reduce_to:{c['event_id']}:{format_decimal(c['new_amount'])}")
        changes_str = '|'.join(c_strs)
        
    method = best_plan.method if best_plan else 'not_recommended'
    
    # PRD §19: Independent safety validation
    safety_result = verify_safety(best_plan, best_combo, sim, requested_amount, desired_date)
    if not safety_result['safe'] and status != 'not_affordable':
        logger.warning(f"Request {req_id} generated an unsafe plan: {safety_result['issues']}")
        
    # Generate explanation via fact-locked engine (PRD §21)
    earliest_str = earliest_full.strftime('%Y-%m-%d') if earliest_full else ''
    # Specific edge case: for affordable_now, PS says earliest date equals request date
    if status == 'affordable_now':
        earliest_str = req_date.strftime('%Y-%m-%d')
        
    decision_facts = {
        'affordability_status': status,
        'recommended_payment_method': method,
        'amount_safe_to_pay': format_decimal(amt_safe),
        'requested_amount': format_decimal(requested_amount),
        'home_currency': home_currency,
        'earliest_date_for_full_payment': earliest_str,
        'spending_changes_needed': changes_str,
        'minimum_balance': format_decimal(min_bal),
        'payment_option_id': best_plan.payment_option_id if best_plan else ''
    }
    
    if method == 'partial_payment' and best_plan and len(best_plan.payments) == 2:
        decision_facts['remaining_amount'] = format_decimal(best_plan.payments[1].amount)
        
    explanation = generate_explanation(decision_facts)
        
    row = {
        'request_id': req_id,
        'amount_safe_to_pay': format_decimal(amt_safe),
        'affordability_status': status,
        'recommended_payment_method': method,
        'payment_plan': plan_str,
        'earliest_date_for_full_payment': earliest_str,
        'spending_changes_needed': changes_str,
        'decision_explanation': explanation
    }
    
    # PRD §20: Output validation
    val_result = verify_output_format(row)
    if not val_result['valid']:
        logger.error(f"Output format invalid for {req_id}: {val_result['issues']}")
        
    return row

def main(dataset_path: str, output_path: str, run_samples: bool = True):
    logger.info("Initializing system...")
    vlm = VLMAdapter()
    llm = LLMAdapter()
    loader = DatasetLoader(dataset_path)
    joiner = DeterministicJoiner(loader)
    normalizer = CurrencyNormalizer(loader.exchange_rates)
    
    # 1. Process Images
    logger.info("Extracting amounts from images...")
    image_amounts = {}
    image_sources = {}
    events_by_id = {event['event_id']: event for event in loader.financial_events}
    for img in loader.images:
        event_id = img['related_event_id']
        image_id = img['image_id']
        try:
            img_path = os.path.join(dataset_path, 'media', 'images', f"{image_id}.png")
            extraction = vlm.extract(image_id, img_path, events_by_id.get(event_id, {}))
            amt = extraction['amount']
            image_amounts[event_id] = amt
            image_sources[event_id] = image_id
        except Exception as e:
            logger.error(f"Error extracting image {image_id}: {e}")
            
    # 2. Process Messages
    logger.info("Parsing messages...")
    structured_messages = []
    for msg in loader.messages:
        try:
            parsed = llm.parse_message(msg['message_text'], msg['message_id'])
            parsed['message_id'] = msg['message_id']
            parsed['user_id'] = msg['user_id']
            parsed['target_event_id'] = msg.get('related_event_id', '')
            structured_messages.append(parsed)
        except Exception as e:
            logger.error(f"Error parsing message {msg['message_id']}: {e}")
            
    # Regression test on samples
    if run_samples and loader.sample_requests:
        logger.info(f"Running regression on {len(loader.sample_requests)} sample requests...")
        for req in loader.sample_requests:
            process_request(req['request_id'], joiner, vlm, llm, normalizer, image_amounts, structured_messages, image_sources)
        logger.info("Sample regression completed.")
            
    # Process Requests
    logger.info(f"Processing {len(loader.requests)} test requests...")
    results = []
    
    for req in loader.requests:
        row = process_request(req['request_id'], joiner, vlm, llm, normalizer, image_amounts, structured_messages, image_sources)
        results.append(row)
        
    logger.info("Writing output...")
    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        fieldnames = ['request_id', 'amount_safe_to_pay', 'affordability_status', 'recommended_payment_method', 'payment_plan', 'earliest_date_for_full_payment', 'spending_changes_needed', 'decision_explanation']
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)
        
    logger.info("Done.")

if __name__ == '__main__':
    base = r'C:\Users\ASUS\Documents\hackerrank-orchestrate-september26-main\dataset'
    out = os.path.join(base, 'output.csv')
    main(base, out)
