from decimal import Decimal
from datetime import date, timedelta
from typing import List, Dict, Optional
from collections import defaultdict
from dateutil.relativedelta import relativedelta
from src.finance.models import CanonicalEvent, PaymentPlan

class Simulator:
    def __init__(self, current_balance: Decimal, minimum_balance: Decimal, events: List[CanonicalEvent], request_date: date):
        self.current_balance = current_balance
        self.minimum_balance = minimum_balance
        self.events = events
        self.request_date = request_date
        self.end_date = request_date + timedelta(days=90)

    def _eligible_events(self) -> List[CanonicalEvent]:
        """Return events that may affect a cash forecast."""
        return [e for e in self.events
                if not (e.status in ('failed', 'cancelled', 'unrealized')
                        or e.direction == 'non_cash'
                        or (e.status == 'pending' and e.direction == 'credit'))]

    def _recurring_streams(self):
        """Infer recurring streams from records, never from category names.

        A stream is identified by category, description, and direction.  It
        needs at least two dated observations, a positive observed cadence, and
        a most-recent observation close enough to the request date to support a
        forward forecast.  The median cadence is used rather than assuming that
        every stream is monthly.
        """
        streams = defaultdict(list)
        for e in self._eligible_events():
            streams[(e.category, e.description, e.direction)].append(e)

        result = {}
        for key, group in streams.items():
            ordered = sorted(group, key=lambda e: e.date)
            # Repeated records on a single date are not recurrence evidence.
            intervals = [(ordered[i].date - ordered[i - 1].date).days
                         for i in range(1, len(ordered))
                         if (ordered[i].date - ordered[i - 1].date).days > 0]
            if len(intervals) == 0:
                continue
            cadence = sorted(intervals)[len(intervals) // 2]
            if cadence < 2 or cadence > 35:
                continue
            latest = ordered[-1]
            # A long-stale stream is unsupported; allow a little calendar drift.
            if latest.date < self.request_date and (self.request_date - latest.date).days > cadence + 7:
                continue
            result[key] = (ordered, cadence)
        return result

    def recurring_event_ids(self) -> set[str]:
        """IDs belonging to streams with actual recurrence evidence."""
        return {e.event_id for group, _ in self._recurring_streams().values() for e in group}
        
    def generate_daily_balances(self, spending_changes: List[Dict] = None, candidate_plan: PaymentPlan = None) -> Dict[date, Decimal]:
        """
        Build daily balance curve from request_date through day 90.
        spending_changes: [{'action': 'stop'|'reduce_to', 'event_id': str, 'new_amount': Decimal}]
        candidate_plan: proposed payment plan to test.
        """
        changes = {c['event_id']: c for c in (spending_changes or [])}
        stream_changes = {}
        for key, (group, _) in self._recurring_streams().items():
            for event in group:
                if event.event_id in changes:
                    stream_changes[key] = changes[event.event_id]
                    break
        
        future_events = []
        eligible = self._eligible_events()
        known_dates = set()
        for e in eligible:
            if e.date >= self.request_date and e.date <= self.end_date:
                future_events.append({
                    'date': e.date, 
                    'direction': e.direction, 
                    'amount': e.home_currency_amount, 
                    'event_id': e.event_id
                })
                known_dates.add((e.category, e.description, e.direction, e.date))

        # Extend each evidenced stream from its latest supplied observation.
        for key, (group, cadence) in self._recurring_streams().items():
            latest_e = group[-1]
            # A 27–32 day history is monthly evidence; preserve its day of
            # month rather than drifting by the differing lengths of months.
            monthly = 27 <= cadence <= 32
            next_d = (latest_e.date + relativedelta(months=1)
                      if monthly else latest_e.date + timedelta(days=cadence))
            while next_d <= self.end_date:
                if next_d >= self.request_date and (*key, next_d) not in known_dates:
                    future_events.append({'date': next_d, 'direction': latest_e.direction,
                                          'amount': latest_e.home_currency_amount,
                                          'event_id': latest_e.event_id, 'stream_key': key})
                next_d = (next_d + relativedelta(months=1)
                          if monthly else next_d + timedelta(days=cadence))
                    
        # Add candidate plan payments
        if candidate_plan and candidate_plan.payments:
            for p in candidate_plan.payments:
                if self.request_date <= p.date <= self.end_date:
                    future_events.append({
                        'date': p.date,
                        'direction': 'debit',
                        'amount': p.amount,
                        'event_id': 'candidate_payment'
                    })
                    
        # Build daily flows
        daily_flow = defaultdict(Decimal)
        for e in future_events:
            if not (self.request_date <= e['date'] <= self.end_date):
                continue
                
            amt = e['amount']
            
            # Apply spending change
            change = changes.get(e['event_id']) or stream_changes.get(e.get('stream_key'))
            if change:
                if change['action'] == 'stop':
                    amt = Decimal('0')
                elif change['action'] == 'reduce_to':
                    amt = change['new_amount']
                    
            if e['direction'] == 'debit':
                daily_flow[e['date']] -= amt
            else:
                daily_flow[e['date']] += amt
                
        # Calculate daily balances
        balances = {}
        bal = self.current_balance
        for i in range(91):
            d = self.request_date + timedelta(days=i)
            bal += daily_flow[d]
            balances[d] = bal
            
        return balances

    def get_baseline_min(self) -> Decimal:
        """Returns the minimum balance over 90 days without any new request or spending changes."""
        balances = self.generate_daily_balances()
        return min(balances.values())

    def check_safety(self, spending_changes: List[Dict], candidate_plan: PaymentPlan) -> bool:
        """Returns True if the plan stays above minimum balance throughout 90 days."""
        balances = self.generate_daily_balances(spending_changes, candidate_plan)
        return min(balances.values()) >= self.minimum_balance

    def earliest_safe_date(self, amount: Decimal) -> Optional[date]:
        """Finds the earliest date to pay the full amount without spending changes.
        Uses suffix-minimum array per PRD section 15."""
        balances = self.generate_daily_balances()
        
        # Build ordered balance list
        days = [self.request_date + timedelta(days=i) for i in range(91)]
        bal_list = [balances[d] for d in days]
        
        # Build suffix minimum array
        suffix_min = [Decimal('0')] * 91
        suffix_min[90] = bal_list[90]
        for i in range(89, -1, -1):
            suffix_min[i] = min(bal_list[i], suffix_min[i + 1])
            
        # Find earliest d where suffix_min[d] - amount >= minimum_balance
        target = self.minimum_balance + amount
        for i in range(91):
            if suffix_min[i] >= target:
                return days[i]
                
        return None
