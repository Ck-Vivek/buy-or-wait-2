from decimal import Decimal
import datetime
from datetime import date
from typing import List, Dict, Optional, Tuple
from collections import defaultdict
from itertools import combinations
import itertools
from src.finance.models import CanonicalEvent, PaymentPlan, Payment
from src.finance.simulator import Simulator

class Solver:
    def __init__(self, simulator: Simulator, requested_amount: Decimal, desired_completion_date: date, allows_partial: bool, payment_preferences: List[str], payment_options: List[Dict], flexible_events: List[CanonicalEvent], max_installment_months: Optional[int] = None):
        self.sim = simulator
        self.requested_amount = requested_amount
        self.desired_completion_date = desired_completion_date
        self.allows_partial = allows_partial
        self.payment_preferences = payment_preferences
        self.payment_options = payment_options
        self.flexible_events = flexible_events
        self.max_installment_months = max_installment_months
        
    def get_amount_safe_to_pay(self) -> Decimal:
        """PRD §14: closed-form safe amount calculation."""
        baseline_min = self.sim.get_baseline_min()
        surplus = baseline_min - self.sim.minimum_balance
        return max(Decimal('0'), min(self.requested_amount, surplus))
        
    def get_earliest_full_date(self) -> Optional[date]:
        """PRD §15: earliest date for full payment without spending changes."""
        return self.sim.earliest_safe_date(self.requested_amount)
        
    def generate_spending_change_combinations(self) -> List[List[Dict]]:
        """Generate all valid combinations of spending changes (up to 3).
        Stop and reduce on the same event are mutually exclusive."""
        
        possible_changes = []
        seen_events = set()
        
        for e in self.flexible_events:
            if e.event_id in seen_events:
                continue
            seen_events.add(e.event_id)
            
            if e.flexibility in ('stoppable', 'reducible_or_stoppable'):
                possible_changes.append({'action': 'stop', 'event_id': e.event_id})
            if e.flexibility in ('reducible', 'reducible_or_stoppable'):
                min_amt = e.minimum_allowed_amount if e.minimum_allowed_amount else Decimal('0')
                if e.home_currency_amount > min_amt:
                    possible_changes.append({'action': 'reduce_to', 'event_id': e.event_id, 'new_amount': min_amt})
                    
        # Group by event_id to prevent picking both stop and reduce for the same event
        events_changes = defaultdict(list)
        for c in possible_changes:
            events_changes[c['event_id']].append(c)
            
        all_combos = [[]]  # Start with empty combo (no changes)
        
        event_ids = list(events_changes.keys())
        
        for k in range(1, min(4, len(event_ids) + 1)):
            for combo_events in combinations(event_ids, k):
                options = [events_changes[eid] for eid in combo_events]
                for specific_changes in itertools.product(*options):
                    all_combos.append(list(specific_changes))
                    
        return all_combos
        
    def generate_candidate_plans(self, amount_safe: Decimal, earliest_full: Optional[date]) -> List[PaymentPlan]:
        """Generate all candidate payment plans per PRD §16."""
        plans = []
        
        # 1. full_payment: pay requested amount now
        if 'full_payment' in self.payment_preferences:
            plans.append(PaymentPlan(method='full_payment', payments=[Payment(date=self.sim.request_date, amount=self.requested_amount)]))
            
        # 2. partial_payment per PS §146:
        # Only when: allows_partial, user accepts partial_payment, 
        # amount_safe > 0 AND < requested_amount,
        # earliest_full exists and <= desired_completion_date
        if (self.allows_partial 
            and 'partial_payment' in self.payment_preferences 
            and amount_safe > 0 
            and amount_safe < self.requested_amount 
            and earliest_full is not None
            and self.desired_completion_date is not None
            and earliest_full <= self.desired_completion_date):
            plans.append(PaymentPlan(
                method='partial_payment',
                payments=[
                    Payment(date=self.sim.request_date, amount=amount_safe),
                    Payment(date=earliest_full, amount=self.requested_amount - amount_safe)
                ]
            ))
                
        # 3. wait: defer full payment until safe future date
        # Eligible when user accepts full_payment and full payment becomes safe later
        if 'full_payment' in self.payment_preferences and earliest_full and earliest_full > self.sim.request_date:
            plans.append(PaymentPlan(method='wait', payments=[Payment(date=earliest_full, amount=self.requested_amount)]))
            
        # 4. installments: use only supplied payment options
        if 'installments' in self.payment_preferences:
            for opt in self.payment_options:
                if opt['payment_method'] != 'installments':
                    continue
                opt_id = opt['payment_option_id']
                num_payments = int(opt['number_of_payments'])
                if (self.max_installment_months is not None
                        and num_payments > self.max_installment_months):
                    continue
                interval = int(opt['payment_frequency_days'])
                start_date = datetime.datetime.strptime(opt['first_payment_date'], '%Y-%m-%d').date()
                payment_amt = Decimal(opt['payment_amount'])
                
                pymts = []
                for i in range(num_payments):
                    d = start_date + datetime.timedelta(days=i * interval)
                    pymts.append(Payment(date=d, amount=payment_amt))
                    
                plans.append(PaymentPlan(method='installments', payments=pymts, payment_option_id=opt_id))
                
        return plans

    def solve(self) -> Tuple[str, Optional[PaymentPlan], List[Dict]]:
        """Main decision engine. Returns (status, best_plan, spending_changes)."""
        amount_safe = self.get_amount_safe_to_pay()
        earliest_full = self.get_earliest_full_date()
        
        candidate_plans = self.generate_candidate_plans(amount_safe, earliest_full)
        change_combos = self.generate_spending_change_combinations()
        
        valid_options = []
        
        for plan in candidate_plans:
            # The PS requires every listed payment to be safety-checked and the
            # request to be complete by its deadline.  A payment outside this
            # simulator's 90-day horizon therefore cannot be called safe.
            if any(p.date < self.sim.request_date or p.date > self.sim.end_date
                   for p in plan.payments):
                continue
            if (self.desired_completion_date is not None and plan.payments
                    and max(p.date for p in plan.payments) > self.desired_completion_date):
                continue
            for combo in change_combos:
                if self.sim.check_safety(combo, plan):
                    valid_options.append((plan, combo))
                    
        if not valid_options:
            return "not_affordable", None, []
            
        def rank_key(item):
            plan, combo = item
            
            # PRD §17 six-level ranking:
            # 1. Complete full request by desired_completion_date
            completed_by_desired = False
            if plan.payments:
                if self.desired_completion_date:
                    last_payment_date = max(p.date for p in plan.payments)
                    completed_by_desired = last_payment_date <= self.desired_completion_date
                else:
                    completed_by_desired = True
            c1 = not completed_by_desired  # False sorts before True
            
            # 2. Require no spending changes
            c2 = len(combo) > 0
            
            # 3. Minimize total amount paid
            c3 = sum(p.amount for p in plan.payments) if plan.payments else Decimal('0')
            
            # 4. Start payment earlier
            c4 = min(p.date for p in plan.payments) if plan.payments else date.max
            
            # 5. Use fewer payments
            c5 = len(plan.payments) if plan.payments else 0
            
            # 6. Lowest payment_option_id
            c6 = plan.payment_option_id if plan.payment_option_id else ""
            
            return (c1, c2, c3, c4, c5, c6)
            
        valid_options.sort(key=rank_key)
        best_plan, best_combo = valid_options[0]
        
        # Status assignment per PS §117-122 (only 4 valid values):
        # affordable_now: full amount safe on request_date AND user accepts full_payment, no changes needed
        # affordable_with_plan: completable using partial, installments, or spending changes
        # affordable_later: full amount expected to become safe later (wait without changes)
        # not_affordable: cannot complete safely
        
        if best_plan.method == 'full_payment' and len(best_combo) == 0:
            status = "affordable_now"
        elif best_plan.method == 'wait' and len(best_combo) == 0:
            status = "affordable_later"
        else:
            # Everything else: partial, installments, full+changes, wait+changes
            status = "affordable_with_plan"
            
        return status, best_plan, best_combo
