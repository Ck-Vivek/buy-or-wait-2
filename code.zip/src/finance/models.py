from dataclasses import dataclass, field
from decimal import Decimal
from typing import List
import datetime

@dataclass
class CanonicalEvent:
    event_id: str
    user_id: str
    date: datetime.date
    amount: Decimal
    currency: str
    home_currency_amount: Decimal
    event_type: str
    category: str
    direction: str
    description: str
    status: str
    recurring: bool
    flexibility: str
    financial_effect: Decimal
    minimum_allowed_amount: Decimal = None
    source_event_ids: List[str] = field(default_factory=list)
    source_message_ids: List[str] = field(default_factory=list)
    source_image_ids: List[str] = field(default_factory=list)
    confidence: float = 1.0

@dataclass
class Payment:
    date: datetime.date
    amount: Decimal

@dataclass
class PaymentPlan:
    method: str  # full_payment, partial_payment, installments, wait
    payments: List[Payment] = field(default_factory=list)
    payment_option_id: str = None
