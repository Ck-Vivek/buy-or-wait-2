from typing import List, Dict, Optional
from decimal import Decimal
import datetime

from src.finance.models import CanonicalEvent
from src.finance.currency import CurrencyNormalizer

class LifecycleResolver:
    def __init__(self, normalizer: CurrencyNormalizer, home_currency: str):
        self.normalizer = normalizer
        self.home_currency = home_currency

    def resolve(self, 
                raw_events: List[dict], 
                structured_messages: List[dict], 
                image_amounts: Dict[str, Decimal], image_sources: Dict[str, str] = None) -> List[CanonicalEvent]:
        """
        Resolves raw events, message actions, and image amounts into CanonicalEvents.
        Applies PS conflict hierarchy:
        1. Explicit cancellation/settlement/amendment
        2. Newer record from the same source
        3. Settled event over estimate/forecast
        4. Financially safer interpretation
        """
        # Step 1: Index raw events and fill blank amounts from images
        events_by_id = {}
        for e in raw_events:
            event_id = e['event_id']
            e_copy = dict(e)
            if not e_copy['amount'].strip():
                if event_id in image_amounts:
                    e_copy['amount'] = str(image_amounts[event_id])
                    e_copy['_image_used'] = True
                else:
                    e_copy['_image_used'] = False
            else:
                e_copy['_image_used'] = False
            events_by_id[event_id] = e_copy

        # Step 2: Process messages into overrides and cancellations
        overrides = {}
        category_overrides = {}
        cancellations = set()
        
        for msg in structured_messages:
            target = msg.get('target_event_id', '').strip() if msg.get('target_event_id') else ''
            action = msg.get('action', 'none')
            user_id = msg.get('user_id', '')
            cat = msg.get('category', '')
            
            if action == 'cancel':
                if target: 
                    cancellations.add(target)
            elif action == 'amend':
                if target:
                    overrides.setdefault(target, []).append(msg)
                if user_id and cat:
                    category_overrides.setdefault((user_id, cat), []).append(msg)
            elif action == 'delay':
                if target:
                    overrides.setdefault(target, []).append(msg)
                    
        # Step 3: Resolve linked_event_id parent-child chains
        children_by_parent = {}
        for e in events_by_id.values():
            parent_id = e.get('linked_event_id', '').strip()
            if parent_id:
                children_by_parent.setdefault(parent_id, []).append(e)

        def has_settled_descendant(event_id, seen=None):
            seen = seen or set()
            if event_id in seen:
                return False
            seen.add(event_id)
            for child in children_by_parent.get(event_id, []):
                if child.get('status') == 'settled':
                    return True
                if has_settled_descendant(child['event_id'], seen):
                    return True
            return False

        resolved_events = []
        
        for event_id, raw_e in events_by_id.items():
            # Skip explicitly cancelled events (from messages)
            if event_id in cancellations:
                continue
            
            # Skip events with failed status - PS says ignore failed transactions
            if raw_e['status'] == 'failed':
                continue
                
            # Skip events with cancelled status - PS says ignore cancelled transactions  
            if raw_e['status'] == 'cancelled':
                continue
                
            # Check if parent is overridden by a settled child
            parent_status = raw_e.get('status', '')
            is_overridden_by_child = (parent_status in ('scheduled', 'pending')
                                      and has_settled_descendant(event_id))
                    
            if is_overridden_by_child:
                continue
                
            # Parse amount
            amount_str = raw_e['amount'].strip()
            if not amount_str:
                continue  # Skip if still empty after image fill
                
            amount = Decimal(amount_str)
            date_str = raw_e['event_date']
            status = raw_e['status']
            currency = raw_e['currency']
            
            # Apply message overrides (direct event target)
            msg_overrides = overrides.get(event_id, [])[:]
            # Apply category-level overrides (e.g. salary changes)
            cat_msgs = category_overrides.get((raw_e['user_id'], raw_e.get('category', '')), [])
            msg_overrides.extend(cat_msgs)
            
            source_msgs = []
            for msg in msg_overrides:
                effective_date_str = msg.get('effective_date', '')
                if effective_date_str and date_str < effective_date_str:
                    continue  # Override hasn't taken effect yet
                    
                source_msgs.append(msg.get('message_id', 'unknown'))
                
                if msg.get('new_amount') is not None:
                    try:
                        amount = Decimal(str(msg['new_amount']))
                        if msg.get('currency'):
                            currency = msg['currency']
                    except Exception:
                        pass
                elif msg.get('amount') is not None:
                    try:
                        amount = Decimal(str(msg['amount']))
                        if msg.get('currency'):
                            currency = msg['currency']
                    except Exception:
                        pass
                        
                # Handle delay action
                if msg.get('action') == 'delay' and msg.get('delay_to_date'):
                    date_str = msg['delay_to_date']
                    
            dt = datetime.datetime.strptime(date_str, '%Y-%m-%d').date()
            
            # Currency normalization
            home_amt = self.normalizer.convert(amount, currency, self.home_currency, date_str)
            
            # Financial effect (direction)
            direction = raw_e.get('direction', 'debit')
            if direction == 'non_cash':
                effect = Decimal('0')
            elif direction == 'credit':
                effect = home_amt
            else:
                effect = -home_amt
            
            # Provenance tracking
            source_images = []
            if raw_e.get('_image_used', False):
                image_id = (image_sources or {}).get(event_id)
                if image_id:
                    source_images = [image_id]
            
            # Parse minimum_allowed_amount
            min_allowed = None
            min_str = raw_e.get('minimum_allowed_amount', '').strip()
            if min_str:
                try:
                    min_allowed = Decimal(min_str)
                except Exception:
                    pass
            
            ce = CanonicalEvent(
                event_id=event_id,
                user_id=raw_e['user_id'],
                date=dt,
                amount=amount,
                currency=currency,
                home_currency_amount=home_amt,
                event_type=raw_e.get('event_type', 'expense'),
                category=raw_e.get('category', ''),
                direction=direction,
                description=raw_e.get('description', ''),
                status=status,
                recurring=False,  # No 'recurring' column in dataset; inferred by simulator
                flexibility=raw_e.get('flexibility', 'fixed'),
                financial_effect=effect,
                minimum_allowed_amount=min_allowed,
                source_event_ids=[event_id],
                source_message_ids=source_msgs,
                source_image_ids=source_images,
                confidence=1.0
            )
            resolved_events.append(ce)
            
        return resolved_events
