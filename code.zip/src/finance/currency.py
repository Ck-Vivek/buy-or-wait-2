from decimal import Decimal
import datetime
from typing import List, Dict, Tuple

class CurrencyNormalizer:
    def __init__(self, exchange_rates_data: List[dict]):
        self.rates: Dict[Tuple[str, str, str], Decimal] = {}
        for row in exchange_rates_data:
            key = (row['from_currency'], row['to_currency'], row['rate_date'])
            self.rates[key] = Decimal(row['rate'])

    def convert(self, amount: Decimal, from_currency: str, to_currency: str, date_str: str) -> Decimal:
        if from_currency == to_currency:
            return amount
        
        key = (from_currency, to_currency, date_str)
        if key in self.rates:
            return amount * self.rates[key]
            
        # In this specific dataset, we verified that all necessary exact matches exist.
        # If it doesn't, we raise an error.
        raise ValueError(f"Exchange rate not found for {from_currency} to {to_currency} on {date_str}")
