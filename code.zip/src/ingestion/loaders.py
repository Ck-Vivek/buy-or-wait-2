import csv
import os

class DatasetLoader:
    """Loads all CSV dataset files into memory."""

    def __init__(self, dataset_dir: str):
        self.dataset_dir = dataset_dir
        
        self.requests = self._load_csv('requests.csv')
        self.sample_requests = self._load_csv('sample_requests.csv')
        self.financial_profiles = self._load_csv('financial_profiles.csv')
        self.financial_events = self._load_csv('financial_events.csv')
        self.request_payment_options = self._load_csv('request_payment_options.csv')
        self.messages = self._load_csv('messages.csv')
        self.images = self._load_csv('images.csv')
        self.exchange_rates = self._load_csv('exchange_rates.csv')

    def _load_csv(self, filename: str) -> list[dict]:
        path = os.path.join(self.dataset_dir, filename)
        if not os.path.exists(path):
            return []
        
        with open(path, 'r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            return list(reader)
