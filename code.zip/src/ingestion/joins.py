from dataclasses import dataclass
from typing import List, Dict, Optional

from src.ingestion.loaders import DatasetLoader

@dataclass
class JoinedRequestData:
    request: dict
    profile: dict
    events: List[dict]
    messages: List[dict]
    payment_options: List[dict]
    images: List[dict]

class DeterministicJoiner:
    """Joins related data for a specific request deterministically."""

    def __init__(self, dataset: DatasetLoader):
        self.dataset = dataset
        
        # Precompute maps for O(1) lookups while maintaining original order
        self.profiles_by_user = {p['user_id']: p for p in dataset.financial_profiles}
        
        self.events_by_user = {}
        for e in dataset.financial_events:
            self.events_by_user.setdefault(e['user_id'], []).append(e)
            
        self.messages_by_user = {}
        for m in dataset.messages:
            self.messages_by_user.setdefault(m['user_id'], []).append(m)
            
        self.options_by_request = {}
        for o in dataset.request_payment_options:
            self.options_by_request.setdefault(o['request_id'], []).append(o)
            
        self.images_by_event = {i['related_event_id']: i for i in dataset.images}

    def get_data_for_request(self, request_id: str) -> JoinedRequestData:
        # Find the request
        req = next((r for r in self.dataset.requests if r['request_id'] == request_id), None)
        if not req:
            req = next((r for r in self.dataset.sample_requests if r['request_id'] == request_id), None)
            
        if not req:
            raise ValueError(f"Request {request_id} not found.")
            
        user_id = req['user_id']
        profile = self.profiles_by_user.get(user_id)
        
        if not profile:
            raise ValueError(f"Profile for user {user_id} not found.")
        
        # Events for the user, maintaining deterministic file order
        events = self.events_by_user.get(user_id, [])
        
        # Messages for the user
        messages = self.messages_by_user.get(user_id, [])
        
        # Payment options for the request
        options = self.options_by_request.get(request_id, [])
        
        # Images corresponding to the user's events
        images = []
        for e in events:
            img = self.images_by_event.get(e['event_id'])
            if img:
                images.append(img)
                
        return JoinedRequestData(
            request=req,
            profile=profile,
            events=events,
            messages=messages,
            payment_options=options,
            images=images
        )
