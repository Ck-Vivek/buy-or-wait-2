"""Run the image ingestion path and print auditable extraction metadata."""

import os
import sys

from src.adapters.vlm import VLMAdapter
from src.ingestion.loaders import DatasetLoader

DATASET = r'C:\Users\ASUS\Documents\hackerrank-orchestrate-september26-main\dataset'


def main():
    dataset = DatasetLoader(DATASET)
    events = {event['event_id']: event for event in dataset.financial_events}
    adapter = VLMAdapter()
    selected = set(sys.argv[1:])
    for image in dataset.images:
        if selected and image['image_id'] not in selected:
            continue
        image_id = image['image_id']
        event_id = image['related_event_id']
        path = os.path.join(DATASET, 'media', 'images', f'{image_id}.png')
        try:
            result = adapter.extract(image_id, path, events[event_id])
            label = result['label'].encode('ascii', 'replace').decode('ascii')
            print(f"{image_id},{event_id},{result['amount']},{result['confidence']},{result['method']},{label}")
        except Exception as error:
            print(f'{image_id},{event_id},UNRESOLVED,,,{type(error).__name__}: {error}')


if __name__ == '__main__':
    main()
