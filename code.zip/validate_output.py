import csv, os, re
from collections import Counter

def validate_output(filepath):
    if not os.path.exists(filepath):
        print(f"Error: {filepath} not found.")
        return

    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        header = next(reader)
        rows = list(reader)

    expected_cols = [
        'request_id', 'amount_safe_to_pay', 'affordability_status', 
        'recommended_payment_method', 'payment_plan', 
        'earliest_date_for_full_payment', 'spending_changes_needed', 
        'decision_explanation'
    ]

    print("--- Validation Report ---")
    
    # 1. Column Check
    print("Column Count:", len(header))
    print("Columns Match Expected Order:", header == expected_cols)
    if header != expected_cols:
        print("Expected:", expected_cols)
        print("Got:", header)

    # 2. Row Count & Duplicates
    print("Total Rows:", len(rows))
    request_ids = [row[0] for row in rows]
    duplicates = [item for item, count in Counter(request_ids).items() if count > 1]
    print("Duplicate Request IDs:", len(duplicates), duplicates if duplicates else "None")

    # 3. Value Validation
    valid_status = {'affordable_now', 'affordable_with_plan', 'affordable_later', 'not_affordable'}
    valid_method = {'full_payment', 'installments', 'partial_payment', 'wait', 'not_recommended'}

    issues = []
    
    for idx, row in enumerate(rows):
        # ensure row has exactly 8 columns
        if len(row) != 8:
            issues.append(f"Row {idx+2}: has {len(row)} columns instead of 8")
            continue
            
        req_id, amt, status, method, plan, earliest, changes, expl = row

        # amount
        try:
            float(amt)
        except ValueError:
            issues.append(f"{req_id}: Invalid amount_safe_to_pay '{amt}'")

        # status
        if status not in valid_status:
            issues.append(f"{req_id}: Invalid affordability_status '{status}'")

        # method
        if method not in valid_method:
            issues.append(f"{req_id}: Invalid recommended_payment_method '{method}'")

        # plan
        if plan != 'none':
            for p in plan.split('|'):
                if not re.match(r'^\d{4}-\d{2}-\d{2}:\d+(\.\d+)?$', p):
                    issues.append(f"{req_id}: Malformed payment_plan part '{p}'")

        # earliest date
        if earliest:
            if not re.match(r'^\d{4}-\d{2}-\d{2}$', earliest):
                issues.append(f"{req_id}: Malformed earliest_date '{earliest}'")
                
        # changes
        if changes != 'none':
            for c in changes.split('|'):
                if not re.match(r'^(stop:event_\d+|reduce_to:event_\d+:\d+(\.\d+)?)$', c):
                    issues.append(f"{req_id}: Malformed spending_changes_needed '{c}'")

        # explanation
        if not expl.strip():
            issues.append(f"{req_id}: Empty decision_explanation")
            
    print(f"\nFound {len(issues)} formatting issues:")
    for issue in issues[:20]:
        print(issue)
    if len(issues) > 20:
        print(f"...and {len(issues)-20} more.")

if __name__ == "__main__":
    validate_output(r'C:\Users\ASUS\Documents\hackerrank-orchestrate-september26-main\dataset\output.csv')
