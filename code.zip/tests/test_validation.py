import unittest
from datetime import date
from decimal import Decimal

from src.finance.models import Payment, PaymentPlan
from src.finance.simulator import Simulator
from src.validation.validators import verify_safety


class TestValidation(unittest.TestCase):
    def test_safety_rejects_payment_after_deadline(self):
        simulator = Simulator(Decimal('1000'), Decimal('0'), [], date(2025, 1, 1))
        plan = PaymentPlan(method='full_payment', payments=[
            Payment(date(2025, 1, 10), Decimal('100')),
        ])
        result = verify_safety(plan, [], simulator, Decimal('100'), date(2025, 1, 5))
        self.assertFalse(result['safe'])
        self.assertTrue(any('after desired completion' in issue for issue in result['issues']))


if __name__ == '__main__':
    unittest.main()