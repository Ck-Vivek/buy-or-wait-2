import unittest
from decimal import Decimal
import datetime

from src.finance.lifecycle import LifecycleResolver
from src.finance.currency import CurrencyNormalizer

class TestLifecycle(unittest.TestCase):
    def test_lifecycle_resolution(self):
        # Setup mock normalizer
        normalizer = CurrencyNormalizer([
            {'from_currency': 'USD', 'to_currency': 'USD', 'rate_date': '2025-01-01', 'rate': '1.0'}
        ])
        resolver = LifecycleResolver(normalizer, 'USD')
        
        raw_events = [
            # A scheduled parent event
            {
                'event_id': 'e1',
                'user_id': 'u1',
                'amount': '100',
                'currency': 'USD',
                'event_date': '2025-01-01',
                'status': 'scheduled',
                'direction': 'debit',
                'linked_event_id': ''
            },
            # A settled child event that overrides the parent
            {
                'event_id': 'e2',
                'user_id': 'u1',
                'amount': '105',
                'currency': 'USD',
                'event_date': '2025-01-01',
                'status': 'settled',
                'direction': 'debit',
                'linked_event_id': 'e1'
            },
            # An event to be amended
            {
                'event_id': 'e3',
                'user_id': 'u1',
                'amount': '200',
                'currency': 'USD',
                'event_date': '2025-01-01',
                'status': 'scheduled',
                'direction': 'debit',
                'linked_event_id': ''
            },
            # An event to be cancelled
            {
                'event_id': 'e4',
                'user_id': 'u1',
                'amount': '300',
                'currency': 'USD',
                'event_date': '2025-01-01',
                'status': 'scheduled',
                'direction': 'debit',
                'linked_event_id': ''
            }
        ]
        
        messages = [
            {'message_id': 'm1', 'action': 'amend', 'target_event_id': 'e3', 'amount': '250', 'effective_date': '2025-01-01'},
            {'message_id': 'm2', 'action': 'cancel', 'target_event_id': 'e4'}
        ]
        
        images = {}
        
        resolved = resolver.resolve(raw_events, messages, images)
        
        # e1 should be overridden by e2
        # e2 should be present (105)
        # e3 should be amended to 250
        # e4 should be cancelled
        
        event_map = {e.event_id: e for e in resolved}
        
        self.assertNotIn('e1', event_map)
        self.assertNotIn('e4', event_map)
        
        self.assertIn('e2', event_map)
        self.assertEqual(event_map['e2'].amount, Decimal('105'))
        
        self.assertIn('e3', event_map)
        self.assertEqual(event_map['e3'].amount, Decimal('250'))

    def test_settled_grandchild_supersedes_scheduled_ancestor(self):
        normalizer = CurrencyNormalizer([
            {'from_currency': 'USD', 'to_currency': 'USD', 'rate_date': '2025-01-01', 'rate': '1.0'}
        ])
        resolver = LifecycleResolver(normalizer, 'USD')
        raw_events = [
            {'event_id': 'parent', 'user_id': 'u1', 'amount': '100', 'currency': 'USD',
             'event_date': '2025-01-01', 'status': 'scheduled', 'direction': 'debit', 'linked_event_id': ''},
            {'event_id': 'pending', 'user_id': 'u1', 'amount': '100', 'currency': 'USD',
             'event_date': '2025-01-01', 'status': 'pending', 'direction': 'debit', 'linked_event_id': 'parent'},
            {'event_id': 'settled', 'user_id': 'u1', 'amount': '105', 'currency': 'USD',
             'event_date': '2025-01-01', 'status': 'settled', 'direction': 'debit', 'linked_event_id': 'pending'},
        ]
        resolved = resolver.resolve(raw_events, [], {})
        self.assertEqual([event.event_id for event in resolved], ['settled'])

    def test_amendment_currency_is_used_for_conversion(self):
        normalizer = CurrencyNormalizer([
            {'from_currency': 'USD', 'to_currency': 'USD', 'rate_date': '2025-01-01', 'rate': '1.0'},
            {'from_currency': 'EUR', 'to_currency': 'USD', 'rate_date': '2025-01-01', 'rate': '2.0'},
        ])
        resolver = LifecycleResolver(normalizer, 'USD')
        raw_event = {'event_id': 'salary', 'user_id': 'u1', 'amount': '100', 'currency': 'USD', 'category': 'salary',
                     'event_date': '2025-01-01', 'status': 'scheduled', 'direction': 'credit', 'linked_event_id': ''}
        message = {'message_id': 'm1', 'user_id': 'u1', 'action': 'amend', 'category': 'salary',
                   'new_amount': '50', 'currency': 'EUR', 'effective_date': '2025-01-01'}
        resolved = resolver.resolve([raw_event], [message], {})
        self.assertEqual(resolved[0].currency, 'EUR')
        self.assertEqual(resolved[0].home_currency_amount, Decimal('100'))

if __name__ == '__main__':
    unittest.main()
