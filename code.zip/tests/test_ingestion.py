import os
import unittest
from src.ingestion.loaders import DatasetLoader
from src.ingestion.joins import DeterministicJoiner

class TestIngestion(unittest.TestCase):
    def setUp(self):
        self.dataset_dir = r'C:\Users\ASUS\Documents\hackerrank-orchestrate-september26-main\dataset'
        self.loader = DatasetLoader(self.dataset_dir)
        self.joiner = DeterministicJoiner(self.loader)

    def test_loaders(self):
        self.assertTrue(len(self.loader.requests) > 0)
        self.assertTrue(len(self.loader.financial_events) > 0)
        self.assertTrue(len(self.loader.messages) > 0)

    def test_joiner(self):
        req_id = self.loader.requests[0]['request_id']
        data = self.joiner.get_data_for_request(req_id)
        
        self.assertEqual(data.request['request_id'], req_id)
        self.assertEqual(data.profile['user_id'], data.request['user_id'])
        self.assertTrue(all(e['user_id'] == data.request['user_id'] for e in data.events))
        self.assertTrue(all(m['user_id'] == data.request['user_id'] for m in data.messages))
        self.assertTrue(all(o['request_id'] == req_id for o in data.payment_options))

if __name__ == '__main__':
    unittest.main()
