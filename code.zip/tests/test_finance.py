import unittest
import datetime
from decimal import Decimal
from src.finance.models import CanonicalEvent
from src.finance.currency import CurrencyNormalizer

class TestFinance(unittest.TestCase):
    def test_canonical_event(self):
        ev = CanonicalEvent(
            event_id="e1",
            user_id="u1",
            date=datetime.date(2025, 1, 1),
            amount=Decimal("100.50"),
            currency="USD",
            home_currency_amount=Decimal("2000.00"),
            event_type="expense",
            category="rent",
            direction="debit",
            description="monthly rent",
            status="settled",
            recurring=False,
            flexibility="none",
            financial_effect=Decimal("-2000.00")
        )
        self.assertEqual(ev.amount, Decimal("100.50"))
        self.assertEqual(ev.confidence, 1.0)
        self.assertEqual(ev.source_event_ids, [])

    def test_currency_normalizer(self):
        rates_data = [
            {'from_currency': 'USD', 'to_currency': 'EUR', 'rate_date': '2025-01-01', 'rate': '0.90'},
            {'from_currency': 'EUR', 'to_currency': 'ZAR', 'rate_date': '2025-01-01', 'rate': '20.0'}
        ]
        normalizer = CurrencyNormalizer(rates_data)
        
        # Test exact match
        amt = normalizer.convert(Decimal("100"), "USD", "EUR", "2025-01-01")
        self.assertEqual(amt, Decimal("90.0"))
        
        # Test same currency
        amt = normalizer.convert(Decimal("100"), "USD", "USD", "2025-01-01")
        self.assertEqual(amt, Decimal("100"))
        
        # Test missing rate
        with self.assertRaises(ValueError):
            normalizer.convert(Decimal("100"), "USD", "ZAR", "2025-01-01")

if __name__ == '__main__':
    unittest.main()
