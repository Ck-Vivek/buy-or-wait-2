import unittest
from datetime import date
from decimal import Decimal

from src.finance.models import PaymentPlan
from src.finance.simulator import Simulator
from src.finance.solver import Solver


class TestSolver(unittest.TestCase):
    def test_profile_installment_limit_filters_supplied_option(self):
        simulator = Simulator(Decimal('1000'), Decimal('0'), [], date(2025, 1, 1))
        solver = Solver(simulator, Decimal('300'), date(2025, 2, 1), False,
                        ['installments'], [{
                            'payment_method': 'installments', 'payment_option_id': 'opt-3',
                            'number_of_payments': '3', 'payment_frequency_days': '7',
                            'first_payment_date': '2025-01-01', 'payment_amount': '100'
                        }], [], max_installment_months=2)
        self.assertEqual(solver.generate_candidate_plans(Decimal('0'), None), [])


if __name__ == '__main__':
    unittest.main()