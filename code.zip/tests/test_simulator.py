import unittest
from decimal import Decimal
from datetime import date
from src.finance.models import CanonicalEvent, PaymentPlan, Payment
from src.finance.simulator import Simulator

class TestSimulator(unittest.TestCase):
    def test_simulator_basic(self):
        events = [
            CanonicalEvent(
                event_id='e1',
                user_id='u1',
                date=date(2025, 1, 15), # past rent
                amount=Decimal('1000'),
                currency='USD',
                home_currency_amount=Decimal('1000'),
                event_type='expense',
                category='rent',
                direction='debit',
                description='rent payment',
                status='settled',
                recurring=True,
                flexibility='fixed',
                financial_effect=Decimal('0')
            ),
            CanonicalEvent(
                event_id='e2a',
                user_id='u1',
                date=date(2025, 1, 10), # past groceries 1
                amount=Decimal('200'),
                currency='USD',
                home_currency_amount=Decimal('200'),
                event_type='expense',
                category='groceries',
                direction='debit',
                description='groceries shopping',
                status='settled',
                recurring=True,
                flexibility='fixed',
                financial_effect=Decimal('0')
            ),
            CanonicalEvent(
                event_id='e2',
                user_id='u1',
                date=date(2025, 2, 10), # past groceries 2
                amount=Decimal('200'),
                currency='USD',
                home_currency_amount=Decimal('200'),
                event_type='expense',
                category='groceries',
                direction='debit',
                description='groceries shopping',
                status='settled',
                recurring=True,
                flexibility='fixed',
                financial_effect=Decimal('0')
            ),
            CanonicalEvent(
                event_id='e3a',
                user_id='u1',
                date=date(2025, 1, 28), # past salary
                amount=Decimal('3000'),
                currency='USD',
                home_currency_amount=Decimal('3000'),
                event_type='income',
                category='salary',
                status='settled',
                direction='credit',
                description='salary payment',
                recurring=True,
                flexibility='fixed',
                financial_effect=Decimal('0'),
                minimum_allowed_amount=None
            ),
            CanonicalEvent(
                event_id='e3',
                user_id='u1',
                date=date(2025, 2, 28), # scheduled salary
                amount=Decimal('3000'),
                currency='USD',
                home_currency_amount=Decimal('3000'),
                event_type='income',
                category='salary',
                status='scheduled',
                direction='credit',
                description='salary payment',
                recurring=True,
                flexibility='fixed',
                financial_effect=Decimal('0'),
                minimum_allowed_amount=None
            )
        ]
        
        req_date = date(2025, 2, 20)
        sim = Simulator(Decimal('5000'), Decimal('1000'), events, req_date)
        
        # e1 was 36 days ago -> should not be projected because it's > 31 days
        # e2 was 10 days ago -> should be projected to Mar 10, Apr 10, May 10
        # e3 is in 8 days -> projected to Mar 28, Apr 28, May 28
        
        daily = sim.generate_daily_balances()
        
        # day 0 is Feb 20. bal = 5000
        self.assertEqual(daily[date(2025, 2, 20)], Decimal('5000'))
        
        # Feb 28 salary +3000 -> 8000
        self.assertEqual(daily[date(2025, 2, 28)], Decimal('8000'))
        
        # Mar 10 groceries -200 -> 7800
        self.assertEqual(daily[date(2025, 3, 10)], Decimal('7800'))
        
        # Check safety with a plan of 1000 on Feb 20
        plan = PaymentPlan(method='full_payment', payments=[Payment(date=date(2025, 2, 20), amount=Decimal('1000'))])
        is_safe = sim.check_safety([], plan)
        self.assertTrue(is_safe)
        
        # Earliest safe date for 7500
        earliest = sim.earliest_safe_date(Decimal('7500'))
        self.assertEqual(earliest, date(2025, 3, 28))

    def test_spending_change_applies_to_projected_stream(self):
        events = [
            CanonicalEvent(event_id='old', user_id='u1', date=date(2025, 1, 1), amount=Decimal('200'),
                           currency='USD', home_currency_amount=Decimal('200'), event_type='expense',
                           category='streaming', direction='debit', description='video plan', status='settled',
                           recurring=True, flexibility='stoppable', financial_effect=Decimal('-200')),
            CanonicalEvent(event_id='recent', user_id='u1', date=date(2025, 2, 1), amount=Decimal('200'),
                           currency='USD', home_currency_amount=Decimal('200'), event_type='expense',
                           category='streaming', direction='debit', description='video plan', status='settled',
                           recurring=True, flexibility='stoppable', financial_effect=Decimal('-200')),
        ]
        simulator = Simulator(Decimal('1000'), Decimal('0'), events, date(2025, 2, 15))
        baseline = simulator.generate_daily_balances()[date(2025, 3, 1)]
        stopped = simulator.generate_daily_balances([{'action': 'stop', 'event_id': 'old'}])[date(2025, 3, 1)]
        self.assertEqual(stopped - baseline, Decimal('200'))

if __name__ == '__main__':
    unittest.main()
