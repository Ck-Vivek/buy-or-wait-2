# Buy or Wait: AI Financial Decision Agent

**Buy or Wait** is an intelligent personal finance decision agent designed to evaluate whether a user can safely afford a discretionary purchase, determine the earliest safe purchase date, recommend optimal payment methods, and propose flexible spending adjustments when necessary.

The agent bridges unstructured real-world multimodal data with deterministic financial cashflow calculations, guaranteeing mathematical correctness and safe financial buffers.

---

## 🏛️ Architecture: The 4-Pillar Design

The system is built upon a clear separation of concerns across four key pillars:

```
┌─────────────────┐       ┌─────────────────┐       ┌─────────────────┐       ┌─────────────────┐
│   AI Perceives  │  ──▶  │ Code Calculates │  ──▶  │  Rules Decide   │  ──▶  │   AI Explains   │
│  (VLM & Parser) │       │   (Simulator)   │       │    (Solver)     │       │  (Rationale)    │
└─────────────────┘       └─────────────────┘       └─────────────────┘       └─────────────────┘
```

1. **AI Perceives**:
   - **VLM (Vision Language Model)**: Analyzes receipt and document images to extract exact transaction amounts and currencies.
   - **LLM Message Parsing**: Ingests unstructured user notes and notification messages to identify amendments, cancellations, salary changes, or scheduled payment delays into canonical financial events.
   - Built-in caching avoids redundant multimodal calls across runs.

2. **Code Calculates**:
   - **Currency Normalizer**: Accurately converts cross-currency transactions into the user's home currency using date-based exchange rates.
   - **Lifecycle Resolver**: Merges baseline recurring events, one-time transactions, parsed text amendments, and vision-extracted receipts into a chronologically ordered canonical ledger.
   - **Cashflow Simulator**: Deterministically projects daily balances forward across a 90-day simulation window, tracking liquidity constraints against minimum safety balance buffers (`minimum_balance_to_keep`).

3. **Rules Decide**:
   - **Solver & Decision Engine**: Evaluates payment affordability across user-accepted payment methods (full upfront, installments, BNPL, credit cards).
   - **Combinatorial Optimization**: Searches for Pareto-optimal combinations of spending cuts (stopping or reducing non-essential expenses in categories user is willing to adjust) if a purchase cannot be afforded outright.
   - Computes exact metrics: `amount_safe_to_pay`, `affordability_status` (`affordable_now`, `affordable_with_plan`, `affordable_later`, or `not_affordable`), and `earliest_date_for_full_payment`.

4. **AI Explains**:
   - Synthesizes clear, actionable, and empathetic justifications for the user.
   - Transparently outlines required budget cutbacks, payment milestones, or the reason a purchase cannot currently be afforded.

---

## 🚀 Setup Instructions

### Prerequisites
- Python 3.10 or higher
- A Google Gemini API key (for VLM and LLM parsing/explanations)

### Installation
1. Clone or navigate to the project directory:
   ```bash
   cd C:\Users\ASUS\Desktop\buy-or-wait
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Set your Gemini API Key:
   - **Windows PowerShell**:
     ```powershell
     $env:GEMINI_API_KEY="your-gemini-api-key-here"
     ```
   - **Windows CMD**:
     ```cmd
     set GEMINI_API_KEY=your-gemini-api-key-here
     ```
   - **Linux / macOS**:
     ```bash
     export GEMINI_API_KEY="your-gemini-api-key-here"
     ```

---

## 💻 Usage

Execute the pipeline via the root entry point `main.py`:

```bash
python main.py --dataset <path_to_dataset> --output <path_to_output_csv>
```

### Command-Line Arguments:
- `--dataset`: Path to the input dataset directory containing the CSV files and media assets.
  - *Default*: `C:\Users\ASUS\Documents\hackerrank-orchestrate-september26-main\dataset`
- `--output`: Path where the resulting decision output CSV will be saved.
  - *Default*: `output.csv` inside the dataset folder.

### Example:
```bash
python main.py --dataset C:\Users\ASUS\Documents\hackerrank-orchestrate-september26-main\dataset --output output.csv
```

---

## 📁 Project Structure

```
buy-or-wait/
├── main.py                     # Root CLI entry point
├── requirements.txt            # Python dependencies
├── README.md                   # Project documentation & overview
├── evaluation/
│   └── usage_report.md         # Token usage & cost estimation report
├── prompts/                    # Prompts for LLM and VLM adapters
├── src/
│   ├── __init__.py
│   ├── main.py                 # Core processing pipeline
│   ├── adapters/               # External AI adapters (Gemini 2.5)
│   │   ├── llm.py              # LLM message parsing & explanations with caching
│   │   ├── vlm.py              # VLM document/receipt extraction with caching
│   │   ├── llm_cache.json      # Cached LLM response store
│   │   └── vlm_cache.json      # Cached VLM response store
│   ├── decision/               # Rule evaluation & scoring
│   ├── explanation/            # Explanation generation logic
│   ├── finance/                # Deterministic financial modeling
│   │   ├── currency.py         # Multi-currency exchange normalizer
│   │   ├── lifecycle.py        # Canonical event ledger & lifecycle resolver
│   │   ├── models.py           # Dataclasses (CanonicalEvent, PaymentPlan, etc.)
│   │   ├── simulator.py        # 90-day balance simulation & safety checks
│   │   └── solver.py           # Payment plan solver & budget reducer
│   ├── ingestion/              # Data parsing & CSV loaders
│   └── validation/             # Sanity checks and schema validation
└── tests/                      # Automated unit test suite
    ├── test_finance.py
    ├── test_ingestion.py
    ├── test_lifecycle.py
    └── test_simulator.py
```

---

## 🧪 Testing

The project includes unit tests covering financial event resolution, cashflow simulation, and currency normalization.

Run all tests using `unittest`:
```bash
python -m unittest discover tests
```

To run a specific test suite:
```bash
python -m unittest tests/test_simulator.py
```
