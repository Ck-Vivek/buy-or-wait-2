import csv, os
from decimal import Decimal
base = r'C:\Users\ASUS\Documents\hackerrank-orchestrate-september26-main\dataset'
with open(os.path.join(base, 'financial_events.csv'), 'r', encoding='utf-8-sig') as f:
    evs = list(csv.DictReader(f))
u5 = [e for e in evs if e['user_id'] == 'user_05']
for e in u5:
    print(f"{e['event_date']} {e['status']} {e['direction']} {e['amount']} {e['category']} {e['description']} {e['event_id']}")
