import csv, os
base = r'C:\Users\ASUS\Documents\hackerrank-orchestrate-september26-main\dataset'
out = list(csv.DictReader(open(os.path.join(base, 'messages.csv'), 'r', encoding='utf-8-sig')))
imgs = list(csv.DictReader(open(os.path.join(base, 'images.csv'), 'r', encoding='utf-8-sig')))
sample_reqs = list(csv.DictReader(open(os.path.join(base, 'sample_requests.csv'), 'r', encoding='utf-8-sig')))

for sr in sample_reqs:
    uid = sr['user_id']
    m = [x for x in out if x['user_id'] == uid]
    i = [x for x in imgs if x['user_id'] == uid]
    if m or i:
        print(f"{sr['request_id']} has {len(m)} messages, {len(i)} images")
